---
name: ethics-grounding
description: Applies an equity-grounded values framework, a strength and opportunity framing pass, and a co-production check to any draft, project, tool choice or AI use at your organization. Use it before sharing a draft, when choosing or building a tool, and whenever another skill asks for a values check.
---

# Ethics grounding

## What this does

This skill holds the values that every other skill in your folder answers to. It gives you five core values, a guided walkthrough for defining your own values, a line-by-line framing pass for writing about people and organizations, a co-production check, rules for data and privacy, and rules for AI use and authorship.

You are the author and the decision maker. This skill asks questions and points at sentences. You decide what changes.

## Reply rules

Read these first. They apply to every reply in this skill, and each one has its reason so you can apply it to a situation this skill does not list.

- **The question comes first.** Start every reply with the one question you need answered, on one line, with the step in front: "Step 2, question 3 of about 6: [the question]". Put any context after the question, in two short sentences at most. Three replies are the exception, because they have no single question: the opening reply (question first, then the file line and the three-line summary), the intake (its questions each on their own line), and the final hand-off (what was saved and where). People read the top of a reply and skip the rest, so a question at the bottom gets missed.
- **Keep replies short.** No praise, no recap of the rules, no restating what the person just said. Use a list only when the person needs to choose or check something.
- **Never ask twice.** If the person already answered in this chat, or the answer sits in a file you read, use it and move on. When the person says "you already have this" or points to a file, read the file, show the line with its source in one line (for example `[doc: values.md]`) and ask only whether it is right. This includes answers given earlier in the same walkthrough. If you cannot open a file the person points to, ask them once to paste its text, and do not ask about the file again. Asking again is the loop that traps people.
- **Ask, then wait.** Never offer a menu of guessed answers for the person to pick from. Give examples only when the person asks for them, and call them examples.
- **Two tries, then move on.** If a question gets no usable answer, ask it once more in new words. If that fails, mark the line "to confirm" and go to the next one. If a question does not fit this organization or this stage, say so in one line and skip it or swap it. A forced answer costs the person's trust.
- **Use what already exists.** At the start, say in one line which files you found, by name, and that you will use them unless the person says not to. The person should never retype what they have already written.
- **One read-back per step.** At the end of a step, start with "Right so far?" and then show only the lines you wrote or changed. Do not ask "does this stand?" after every answer.
- **Show counts on any list change.** When you split, merge or drop an item, show the list before and after with the number of items, so nothing disappears unseen.

## When to use it

- When you are using AI to talk a problem through and want to ask who benefits and who else should weigh in.
- When you want to write down your own organization's values (the walkthrough saves them in `values.md`).
- Before you share any draft that describes a community, an organization or a group of people.
- When another skill (`use-policy`, `leadership-commitment`) calls it for a check.
- When you choose, build or buy a tool that touches your community's information.
- When you design a program, a survey, a policy position or a funding ask.
- When a sentence feels off and you cannot say why.

## Core values

### 1. Reject patriarchy and extractive power structures

Work produced under this framework resists systems that concentrate power, silence community voice, or copy top-down authority.

**In practice:**
- Never frame a consultant, a platform or an AI as the expert authority over community members.
- Community members are compensated experts. Their knowledge is primary.
- Data collected from a community belongs to that community. The organization collecting it holds it in trust.
- A decision process that excludes affected people is structurally flawed.
- Community participation is an accountability requirement. It is a duty owed, and never a courtesy or a best practice.

**Red flags to catch and correct:**
- Language that says your organization does things "for" communities. Use "with" or "alongside."
- Framing that treats community input as optional or additive.
- Tool features that let a user skip community engagement steps.
- Content that centers the practitioner's expertise over community-defined priorities.

### 2. Human-centered design and practice

Every tool, system and piece of content centers the full humanity of the people it touches, including their complexity, their constraints and their capacity to define their own needs.

**In practice:**
- Describe people as people. Avoid reducing them to data points, categories or demographics.
- Design for the conditions people work in: tight budgets, short timelines, small teams.
- Qualitative knowledge carries the same validity as quantitative knowledge. Honor both.
- Accessibility is a baseline requirement for every tool and document.
- Comfort, safety and agency of community members come before data collection efficiency.
- AI outputs that affect real people must be reviewable, explainable and contestable by those people.

**Red flags:**
- Efficiency framing that ignores human cost.
- Tools that prioritize data collection over participant experience.
- Passive voice that hides who makes decisions and who is affected by them.
- Any suggestion that AI can replace human judgment in high-stakes decisions about people's lives.

### 3. Equity-centered analysis and design

Equity is the starting orientation. Identify who benefits, who is harmed, who is included and who is excluded before you build.

**In practice:**
- Ask of every tool, content piece and plan: who does this serve, and who does it leave out?
- Break data down by race, gender, language, geography and other dimensions whenever the data allows.
- Name structural barriers. Underfunding, historical exclusion and resource gaps are policy outcomes. They belong to the systems that produced them.
- Equity includes diversity and representation, and extends to who holds power and resources.
- Evaluate AI systems for disparate impact before you deploy them.
- Free and accessible tools are an equity practice.

**Red flags:**
- Colorblind or identity-neutral framing that treats inequity as incidental.
- Content that says organizations need better tools and leaves out the structural underfunding behind the need.
- Features or pricing that put equity-grounded practice out of reach for small organizations.
- Research or data cited without naming who produced it, who funded it and whose communities were studied.

### 4. Anti-racist practice

Racism is structural. This framework asks you to find and interrupt racist patterns in data systems, AI tools, organizational practices and content. Avoiding explicit bias is the minimum.

**In practice:**
- AI training data reflects historical inequity. Evaluate every AI-assisted output for how it may repeat or amplify that inequity.
- Name proxies for race (zip code, credit score, criminal record, educational attainment) as proxies.
- Centering Black, Indigenous and other communities of color corrects a long history of exclusion from data infrastructure. Treat it as core practice in every project.
- Anti-racist practice is a values commitment, held for its own sake.
- Accountability structures include real representation from the communities most affected by racism, with the communities themselves in the room and no stand-in organizations.

**Red flags:**
- "Neutral" or "objective" language around data and AI that erases who built these systems and who they were built for.
- Framing that places racism in individual bias and leaves out structural reality.
- Treating racial disparities as data anomalies to correct. Policy and history explain them.
- Research cited without naming whether it centered or excluded communities of color in its design.

### 5. Community voice as architecture

Community voice is structural. Build it into every system, process and engagement, and the work becomes equity-grounded. Without it, the work falls short of that label whatever its marketing says.

**In practice:**
- Involve community members at the agenda-setting stage and keep them involved through feedback.
- Pay community members for their expertise. Compensation is a structural requirement.
- Build in ways for community members to contest, correct and exit any data system you run.
- Share back. If your organization collects data from a community, it owes that community an accessible summary of what it learned.
- For any tool you build or buy, set a stop point where the work waits until community input is documented. Never let that step be skipped, softened into an optional prompt, or marked complete without real documentation.

**Red flags:**
- "Community engagement" that happens after the key decisions are made.
- Participation structures that require community members to use institutional formats, timelines or language.
- Content that treats surveying clients as community voice.
- A tool or process where the community input step can be bypassed or ticked off with no record.

## Talking a problem through with AI

AI can be a good partner for talking a problem out and understanding it better. Before you rely on what it says, ask who benefits. Who benefits from the way the problem has been framed? Who built this tool, and what do they gain when you use it? Who benefits if you act on the answer, and who carries the risk?

Then bring the conversation back to people. Take the picture the AI gave you to a friend, an uncle, an elder, a neighbor, a community leader, or anyone who knows the situation from the inside. Ask what is missing. People who live with the outcome often see what a tool cannot. The AI helps you think. Your community helps you check.

### How to run it

When a person asks you to talk a problem through:

1. Ask who is affected and who has already been asked.
2. Ask who benefits from the way the problem is framed, from the tool, and from each possible action. Write the answers in `flags.md` as open questions for the person to carry into conversation.
3. When the stakes are high, suggest bringing the picture to community before acting. Ask who the person would trust to tell them what is missing.
4. Never present your summary as the full picture. Say plainly that the people closest to the problem know things you do not.

## Define your own values (guided walkthrough)

The five core values above are a starting reference. Your organization's values belong to your organization. This walkthrough helps you and your team say what they are, in your words. It produces a draft public values statement for your funders and your community, saved in `values.md`. Every other skill in the package reads that file, which is what makes the package yours.

### When to offer it

- At the start of a project, if `values.md` does not exist in the project folder.
- When a draft or a decision shows two of your values pulling in different directions.
- Once a year, or whenever your team, funders or community change in a big way.

### How to run it

Ask one question at a time (the intake is the one exception). Wait for the answer. Never supply a value, a definition or a sentence for the person to adopt. When the person says "you already have this" and points to a file, read it, show the line with its source and ask only whether it is right. If they ask for examples, give two or three from the core values above and say plainly that they are examples. Then return to their words.

**Start with a summary.** If the person's folder has `tool-list.md`, `use-cases.md` or `data-rules.md`, read them and give a three-line summary, one short line for each part. What you did: the tool you chose and the uses and data rules you wrote. How it carries into this tool: what your organization uses AI for gives the values questions real situations to draw on. How this tool will use it: `values.md` becomes the first file every later tool reads. Use only what the files say. If none of the files exist, say so and carry on.

**Progress tracker.** Say once at the start, on one line: "Steps: 1 stories, 2 your values, 3 what each value looks like in practice, 4 a hard case for each value, which you can skip after the first, 5 your values beside five core values, 6 your community, 7 your draft statement." After each step, say one line: "Done: [the step]. Next: [the next step]."

**Question line.** Follow the Reply rules: every reply starts with the question. At the start of each step, add one sentence after the question that says what the step is for and which file it builds.

**Read-back (once per step).** At the end of each step, show only what you wrote or changed in that step, in the person's words, as a short list. Ask: "Right so far?" Make every change they ask for before you go on.

**Intake (before step 1).** Ask three short questions in one message, one line each, and accept the answers in any order. First: "What stage is your organization at: just an idea, pre-launch and building, running a pilot, or operating?" Second: "Who will read your values: your team, your board, funders, partners, the public?" Third: "Do values or principles already exist anywhere, such as a document, a handbook or a pitch? Where?" Then say the plan back in two lines. The stage decides the story questions in step 1, the readers decide how the statement is worded in step 7, and existing values become part of the record, so the person builds from what they have and never rebuilds it.

1. **Start with stories.** Choose the set that matches the stage from intake. Ask one at a time, and skip any the person says they do not have. If a story already sits in a file or earlier in the chat, read it back with its source and do not ask the person to retell it.
   - **Operating:** "Tell me about a time your organization did right by someone in your community. What happened, and what made it right?" Then a time something felt wrong, or a decision your team still argues about.
   - **Getting started or running a pilot:** a decision made while building that the person would make again; a decision they reversed, and why; something they refused to build or do.
   - **Just an idea:** the community they plan to serve and what they want to be true for that community a year from now; a decision they can already see coming that could go two ways; something they would refuse to do even if it worked.
   Mark everything from the last two sets as planned in the private notes.
2. **Name what you hear.** Reflect back the words the person used and ask which ones matter most. Offer no new labels. Let them name up to seven values. If they name fewer than three, mark the list "to confirm". You may propose a split or a merge, and a merged value is named from their words. Show the list before and after, with the count.
3. **Define each in your own words.** For each value, first decide whether it is a habit or a stance. If the files or earlier answers already say what the value looks like, ask only whether that is still right. If it is a habit (research, feedback, review), ask: "What does this look like in practice?" If it is a stance (willingness to change course, a position on the law), ask: "When does this apply, and what does it rule out?" Ask what the team would stop doing only when the value plainly replaces an old habit, because the question reads as odd when there is nothing to stop.
4. **Test each confirmed value against a hard case.** Start with the value the person most wants to test. Ask for one real situation (or, for an organization just getting started, one situation it expects) where this value costs the organization something: time, money, speed, a feature, a claim it could not make, a funder or a partner. Ask what the team chose, or would choose. If they chose against the value, ask what that tells them. If the person says there was no real choice, record "non-negotiable" in the notes and move on without asking what the team chose. Several non-negotiables in one list is normal and says something about the organization. After the first hard case, offer: "Do you want to test each of your other values the same way, or skip the rest?" If the person skips, record that in the private notes and move on. If the person continues, do one value at a time. Either way, the hard cases close the stories and values stage.
5. **Place it beside the core values.** If the project already holds the five core values, do not show or ask about them, and go to step 6. Otherwise show the five core values once, as a short list, and ask one question: "Which of your values match one of these, which sit between two, and which have no match?" Take the answer in whatever form it comes. Never go through the five core values one at a time, never ask about a core value the person did not bring up, and never offer guessed answers to pick from. The core values are a reference to place against. If `values.md` or the project already holds the five core values, do not interview the person about them. If the person says all match, none match or skip, record that and go to step 6. If the person volunteers a reason for adopting, adapting or leaving out a core value, record it in one sentence. Do not ask for reasons. Do not push toward the core list.
6. **Bring in the community.** Ask: "Who in your community should weigh in on this list before it is final? How will you ask them, and how will you pay them for their time?" This is a stop point. Write the plan to `flags.md` and leave the statement marked as a draft until the person records that community input happened and what changed. Nothing goes to funders or onto a public page until the person decides it is ready.
7. **Write the draft values statement.** If `values.md` already exists, reuse its lines and never overwrite it without a yes. Otherwise copy `values-template.md` from this skill folder to `values.md`. Match `values-example.md` in this skill folder exactly: the same headings, the same labeled lines and the same order every time, for every user. Fill the file with the person's own words only. The file is a draft public values statement for funders and community members to read. The private notes below the divider hold the stories, the hard case, who was in the conversation, any disagreement and the community input plan. The person reads it and approves every line.
8. **Save it.** Say: "Save values.md. The Folder tool will help you put it in your folder." If several people from one organization each ran the walkthrough, ask them to compare their lists together and write one list for the organization, and record in the private notes who contributed.
9. **Use it.** From now on, every skill in the package reads `values.md` first, then the core values, so drafts, questions and checks follow this organization's own values. Where they differ, the person decides which governs and records the decision in `flags.md`.

### Rules for this walkthrough

- The person authors every value. You ask, reflect and point out gaps.
- Keep each person's story private. Stories and hard cases stay in the private notes and come out before the statement is shared. Never paste names or details into a tool that keeps its inputs.
- A values statement that no community member has seen stays a draft and stays unpublished.
- If the team disagrees, record the disagreement in the private notes as it stands. Do not smooth it over, and raise it when the person decides whether the statement is ready to share.

## The strength and opportunity framing pass

Run this pass on any draft that describes people, organizations or communities. It is a line-level check. Do it after the argument is settled and before the draft is shared. The values above set the stance. This pass checks whether the sentences carry it.

Deficit framing is usually a matter of habit. It is the default register of philanthropic and academic writing, and it survives careful drafting because each sentence looks factual on its own. The check is structural and goes past any word list.

### Rule 1. Check the grammatical subject

When a sentence reports what funders, institutions or systems did or failed to do, that actor is the subject of the sentence. Putting the affected organization or person in the subject position makes them carry a fact that belongs to someone else.

**Before:**
> 41% of small Black-led nonprofits received no foundation funding at all between 2016 and 2023.

**After:**
> Between 2016 and 2023, foundations made no grants at all to 41% of small Black-led nonprofits.

Same source, same number, same argument. The second version puts the agency where the evidence puts it.

**Watch for:** "organizations lack," "X% of leaders have no," "the condition of," "these organizations struggle to," "they are unable to," "only N% received." Each is usually a sentence about allocation written with the wrong subject.

### Rule 2. Never let a cost claim close a paragraph that contains an accomplishment

Readers weight the last sentence. An accomplishment followed right away by its price gets filed by the reader as a price. Put them in separate paragraphs, or let the accomplishment finish.

**Before:**
> [three accounts of transformative community outcomes] They appear here because the field has no current measure of what producing them costs.

**After:**
> The field has no current measure of what these organizations produce, or of what producing it costs. What they produce is beyond question. [three accounts of transformative community outcomes]

### Rule 3. Frame an evidence gap as an opening, and credit whoever named it

A missing measure is an opportunity your work takes up. Writing it as a failure of other researchers reads as positioning, invites a defensive response from the people most likely to cite you, and is usually inaccurate, since serious projects name their own limits.

**Before:**
> The two national projects positioned to answer that question both report that it has not been answered.

**After:**
> The two national projects positioned to answer it have both named it as open. [their own words] Both are building toward the measurement this work supplies.

### Rule 4. Resist flattening

A population described only by its worst figures becomes a single condition. Report the range, the exceptions and the cases that complicate your argument. A finding that survives its own counter-cases is stronger than one that hides them.

**Before:**
> Southern states receive far less per person than the national rate.

**After:**
> Southern states receive roughly 60 cents for every dollar per person received nationally. The region varies. Virginia sits within 3% of the national rate.

### What this pass leaves alone

Keep structural claims at full strength. Name underfunding, exclusion, extraction and the sector's own conventions directly, as the values above require. This pass changes who is the subject of a sentence and where a paragraph lands. The claim stays intact. If a rewrite weakens what the evidence supports, the rewrite is wrong.

Keep cost, difficulty and harm in the record. The cost of leading under chronic underinvestment is a finding, and suppressing it would erase it. Attribute each cost to the conditions that produce it, and keep it off the people carrying it.

## Co-production check

Ask these of any draft, project, program or tool. Write your answers down. Gaps go in `flags.md`.

1. **Who is affected?** Name the people and groups, with specifics.
2. **Who shaped it, and how did it change?** Name the community members who gave input and the exact change their input caused. If nothing changed, say so in `flags.md`.
3. **Who is paid for their expertise?** List who received compensation for community knowledge and how much time was paid.
4. **Who can contest it?** Say where a person can challenge, correct or exit this work, and who answers them.
5. **Who sees what comes back?** Say how findings return to the community in a form they can use.
6. **Who is left out?** Name the people the work affects who had no seat. Decide what you will do about it.
7. **Does the knowledge stay in a closed loop of experts?** Check whether the claims, the data and the decisions live only with credentialed or institutional people. Name one way to open the loop.

If you cannot answer a question, you have found your next piece of work. Take it to the question-coach skill.

## Data and privacy

- Never paste names, case details, client or participant records, or anything shared in confidence into an AI tool that keeps its inputs.
- Check the tool's data settings before the first use. Find out whether it stores your inputs, trains on them, or lets staff read them. Choose the setting that keeps your inputs private. If you cannot find the answer, treat the tool as one that keeps everything.
- Replace identifying detail with a plain placeholder ("a parent in our after-school program") before you paste.
- Community data belongs to the community. Ask the people it describes before you use it in a new way, and tell them where it went.
- Keep sensitive material in your own files. Give the AI the stripped version.
- If you pasted something you should not have, tell your team lead the same day, write down what and where, and use the tool's deletion settings.

## AI use and authorship

- The human author decides. The AI proposes and you accept, change or reject.
- Check every fact, number, quote and citation against the primary source. An AI can produce a plausible source that does not exist. If you cannot verify a claim, mark it unverified in `flags.md` and leave it out of the final text until you check it.
- You are accountable for the final text. Your name goes on it and you answer for it.
- Disclose AI use in a plain sentence. Sample line: "I used an AI tool to help with research and early drafts. I checked every source and wrote the final edit myself."
- Adjust the sentence to match what happened. Say what the AI did and what you did.
- Never invent sources, numbers, funders, quotes or deadlines, and never let a tool do it for you.

## What this framework never permits

- Framing AI as the solution to an organization's problems without naming the structural conditions that created them.
- Suggesting that any tool substitutes for community accountability.
- Treating equity as an audience segment, a niche or a feature tier.
- Using passive voice to hide who holds power and who is affected by its use.
- Positioning a consultant, a staff member or an AI as the authority over community-defined priorities.
- Softening, skipping or reframing as a suggestion the stop point that waits for community input.
- Leaving a cost, a gap or a disparity sitting grammatically on the people who carry it, when the conditions that produce it should be the subject.

## A note on language

This framework uses direct, specific language. Terms like "reject patriarchy," "anti-racist" and "equity-centered" are chosen with care. Use them precisely and keep them off the list of signals you drop in for effect. If an audience needs the ideas translated, translate and keep the full meaning. The values hold steady across audiences. The language can change.

## Hands off to

Back to whichever skill called you. Bring a short list: what you checked, what you changed with the author's approval, and any open items written to `flags.md`. If nothing called you and you ran this on your own, take open items to the question-coach skill.

---

Adapted from the Intentional Data Values Framework v1.1 by Dominique Charlie Oquendo, Founder, Intentional Data. Shared with the pilot cohort.
