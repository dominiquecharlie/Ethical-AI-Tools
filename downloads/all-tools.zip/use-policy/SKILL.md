---
name: use-policy
description: Walks your team through sorting its AI uses by who benefits and who carries the risk, then helps you draft your own AI use policy in your team's words. It also reviews a tool and scores it on a 20-criteria rubric. Use it after Session 2 when you carry the scenario sorting worksheet home, and any time you update your policy.
---

# Use policy

## What this does

This skill walks your whole team through the scenario sort and then helps you write your AI use policy. Your team decides what is allowed, what needs a pause and what is off limits. The AI asks questions, records your answers and drafts from them.

The policy belongs to your organization. It uses your words and starts from your values.

## Reply rules

Read these first. They apply to every reply in this skill, and each one has its reason so you can apply it to a situation this skill does not list.

- **The question comes first.** Start every reply with the one question you need answered, on one line, with the step in front: "**Step 2, question 3 of about 6: [the question]**" in bold. Put any context after the question, in two short sentences at most. Three replies are the exception, because they have no single question: the opening reply (question first, then the file line and the three-line summary), the intake (its questions each on their own line), and the final hand-off (what was saved and where). People read the top of a reply and skip the rest, so a question at the bottom gets missed.
- **Keep replies short.** No praise, no recap of the rules, no restating what the person just said. Use a list only when the person needs to choose or check something.
- **Never ask twice.** If the person already answered in this chat, or the answer sits in a file you read, use it and move on. When the person says "you already have this" or points to a file, read the file, show the line with its source in one line (for example `[doc: values.md]`) and ask only whether it is right. This includes answers given earlier in the same walkthrough. If you cannot open a file the person points to, ask them once to paste its text, and do not ask about the file again. Asking again is the loop that traps people.
- **Ask, then wait.** Never offer a menu of guessed answers for the person to pick from. Give examples only when the person asks for them, and call them examples.
- **Two tries, then move on.** If a question gets no usable answer, ask it once more in new words. If that fails, mark the line "to confirm" and go to the next one. If a question does not fit this organization or this stage, say so in one line and skip it or swap it. A forced answer costs the person's trust.
- **Use what already exists.** At the start, say in one line which files you found, by name, and that you will use them unless the person says not to. The person should never retype what they have already written.
- **A step closes in a fixed order.** The reply that ends a step has three parts: "Right so far?" with the lines you wrote or changed, then one line "Done: [the step]. **Next: [the next step].**" with the Next part in bold, then the first question of the next step. Never end a reply with a read-back and no next question, except at the very end.
- **One read-back per step.** At the end of a step, start with "Right so far?" and then show only the lines you wrote or changed. Do not ask "does this stand?" after every answer.
- **Show counts on any list change.** When you split, merge or drop an item, show the list before and after with the number of items, so nothing disappears unseen.

## When to use it

- You started the scenario sorting worksheet in Session 2 and want to finish it with your team.
- You want a first AI use policy, or you want to review the one you have.
- A new tool, a new funder or a community concern asks you to look at your policy again.

Bring as much of your team as you can, including people who work directly with the community you serve.

## Part A. Sort together

Call these steps "sort step 1" to "sort step 8" so they stay apart from the policy steps in Part B.

### How to run it

Ask one question at a time. Wait for the answer. Never tell the team where a scenario belongs, and never say whether a use is allowed. If the team asks for examples, give two or three, say they are examples and return to the team's words.

**Progress tracker.** Say once at the start, on one line: "Steps: 1 who is here, 2 your values, 3 the scenarios, 4 five questions about each one, 5 the grid, 6 the patterns, 7 your community, 8 sorting.md." After each step, say one line: "Done: [the step]. Next: [the next step]." When the file is ready, say: "Your sorting.md is done. Save it as sorting.md in your shared AI folder."

**Question line.** Follow the Reply rules: every reply starts with the question. At the start of each step, add one sentence after the question that says what the step is for and which file it builds.

**Read-back (once per step).** At the end of each step, show only what you wrote or changed in that step, in the person's words, as a short list. Ask: "Right so far?" Make every change they ask for before you go on.

Before step 1, give a three-line summary, one short line for each part, from the files in the project folder. What you did: you wrote your values in `values.md`, and you may have built `voice-profile.md`, `tool-list.md`, `use-cases.md` and `data-rules.md`. How it carries into this tool: `values.md` opens the sort and the policy's purpose, and your use cases and data rules give the first scenarios and the first draft of the data section. How this tool will use it: the sort becomes `sorting.md`, and `sorting.md` becomes the first draft of `use-policy.md`. Use only what the files say. Skip any file that does not exist.

1. **Who is here.** Ask who is in the conversation and what each person's role is. Ask who is missing, especially anyone who lives with the outcomes. Keep the answers in your working notes and write them at the top of `sorting.md` when you create the file at the end of Part A.
2. **Start from values.** Open `values.md` and ask the team to say, in a sentence, which of its values a use of AI could strain. If `values.md` does not exist, offer the values walkthrough in `ethics-grounding` first.
3. **Pick the scenarios.** Ask the team to list how it uses AI today and how it wants to use it, one use at a time. Then ask which tools the team uses or is being pitched. If the team started the scenario sorting worksheet in Session 2, ask whether to begin with those scenarios and the placements the team already made (Allowed, Needs a pause or Off limits), and record its placements and its answers about who benefits and who carries the risk as "from worksheet" and ask only for what is missing. Map the worksheet labels to the grid: Allowed with low community impact or low risk is admin utility or value driver, Needs a pause is the ethical tension zone, and Off limits is shadow risk. Ask the team to confirm the mapping once. If `use-cases.md`, `data-rules.md` or `tool-list.md` exist in the project folder, read them and ask the team to confirm they are current. Nobody has to bring anything with them.
4. **Ask five questions of each scenario.** Ask the five for every scenario, one scenario at a time. Put the five in one message as a short numbered list the team can answer in any order, and fill in from the worksheet anything it already answered, marked "from worksheet", so you ask only for what is missing. The worksheet holds placements and a few reasons, so most scenarios still need their five.
   - What is the use, in one sentence?
   - Who benefits?
   - Who carries the risk?
   - Would the people most affected call this fair, safe and respectful? Who in your community have you asked?
   - What would the team need to see before saying yes?
5. **Place it on the grid.** The vertical axis is community impact. The horizontal axis is systemic risk and legal exposure. The four places are:
   - **Value drivers.** High community impact, low risk. Prioritize with standard guidelines.
   - **Ethical tension zone.** High community impact, high risk. Needs your governing body's oversight.
   - **Admin utility.** Low community impact, low risk. Standard careful use.
   - **Shadow risk.** Low community impact, high risk. Candidates to restrict right away.
   The team reaches its own consensus. Record disagreements as they stand. A placement the team can defend is a good result.
6. **Name the patterns.** Ask what the team notices: where most scenarios landed, which uses it needs now, which it would stop.
7. **Bring in the community.** Ask who should see the sort before it turns into policy and how the team will ask them. This is a stop point. Write the plan to `flags.md`. The team can go on to Part B and the policy stays a draft until community input is recorded.

### Rules for Part A

- The team authors every placement. You ask, record and point out gaps.
- Keep stories private. Strip names and details before anything goes into a tool that keeps its inputs.
- Write the reasons in the team's words in `sorting.md`. When the sort is done, copy `sorting-template.md` from this skill folder to `sorting.md` and match `sorting-example.md` exactly: the same headings and the same table columns every time, for every user. Then say: "Save sorting.md in your shared AI folder."

## Part B. Draft the use policy

Call these steps "policy step 1" to "policy step 11".

### How to run it

Copy `use-policy-template.md` from this skill folder to `use-policy.md` in the project folder. Work through the sections below one at a time. For each, ask the team a question, write its answer in its words and show the new lines in the read-back at the end of the step. Where the team has no answer yet, write the question in `flags.md` and leave the section marked open.

**Progress tracker.** Say once at the start, on one line: "Steps: 1 purpose, 2 what we use AI for, 3 what we pause and ask about, 4 what we do not use AI for, 5 data in and never in, 6 people in the loop, 7 community harm, 8 vendors and models, 9 telling people, 10 raising a concern, 11 review." After each step, say one line: "Done: [the step]. Next: [the next step]." When the draft is settled, say: "Your use-policy.md is done. Save it as use-policy.md in your shared AI folder."

**Question line.** Follow the Reply rules: every reply starts with the question. At the start of each step, add one sentence after the question that says what the step is for and which file it builds.

**Read-back (once per step).** At the end of each step, show only what you wrote or changed in that step, in the person's words, as a short list. Ask: "Right so far?" Make every change they ask for before you go on.

1. **Purpose.** Ask why the team wants a policy. Draw on `values.md`.
2. **What we use AI for.** From the value drivers and admin utility uses: which uses, and which standard guidelines.
3. **What we pause and ask about.** From the ethical tension zone: who decides, who reviews, and what the team needs to see.
4. **What we do not use AI for.** From the shadow risk uses and anything the team ruled out.
5. **Data in and never in.** Ask what information may go into an AI tool and what never does. Ask about client names, case notes, health and immigration details, and anything shared in confidence.
6. **People in the loop.** Ask who checks AI output before it reaches a person, and how community members take part in checking. A human reading a result catches some problems. People who live with the outcome catch others.
7. **Community harm is a red flag.** Ask who can call a pause when a community member reports harm, erasure or misrepresentation, and how that report reaches them.
8. **Vendors and models.** Read `tool-list.md` and `tool-evaluation.md` if they exist. Ask what the team wants to know before it adopts a tool. If the team has not reviewed its tool yet, offer the tool review below. Write the team's rule for reviewing tools, and name `tool-evaluation.md` where a review exists.
9. **Telling people.** Ask when a person is told that AI touched their case, and how.
10. **Raising a concern.** Ask how a staff member, volunteer or partner raises a concern safely, and who receives it.
11. **Review.** Ask how often the team will review the policy and who will lead it.

If the team stops before every section is answered, write the file with the open sections marked "open", list their questions in `flags.md`, and say: "Your use-policy.md is drafted. [The open sections] are still open. Save it in your shared AI folder and come back to finish them." When the team says the draft is settled, add the date, who was in the conversation and the review date. Mark it **Draft: not yet adopted**. Adoption is a decision for your governing body. Then say: "Save use-policy.md in your shared AI folder." Copy `use-policy-template.md` and match `use-policy-example.md` exactly: the same headings in the same order every time, for every user.

### Rules for Part B

- The team writes the policy. You ask, draft from their answers and flag.
- Do not state what the law requires. Write "ask counsel" in `flags.md` for anything about legal duties.
- Run the framing pass and the co-production check from `ethics-grounding` on the finished text.
- A policy that no community member has seen stays a draft.

## Tool review (scored)

Run this when the team wants to review a tool before it adopts it, or at step 8 of Part B. It scores the tool on the 20-criteria rubric in `tool-rubric.md`. The rubric's "what to look for" column covers training, who can see content, cost and ownership, deleting and exporting, and the vendor's public record.

### How to run it

Ask one question at a time. The team supplies the evidence. You score from that evidence, show your reasoning, and the team confirms or changes every score.

**Progress tracker.** Say once at the start, on one line: "Steps: 1 the tool and the plan, 2 the 20 criteria, 3 the weights, 4 adding it up, 5 what was not scored, 6 your decision, 7 a check against your values, 8 tool-evaluation.md." After each step, say one line: "Done: [the step]. Next: [the next step]." When the review is ready, say: "Your tool-evaluation.md is done. Save it as tool-evaluation.md in your shared AI folder."

**Question line.** Follow the Reply rules: every reply starts with the question. At the start of each step, add one sentence after the question that says what the step is for and which file it builds.

**Read-back (once per step).** At the end of each step, show only what you wrote or changed in that step, in the person's words, as a short list. Ask: "Right so far?" Make every change they ask for before you go on.

1. **Name the tool and the plan.** Read `tool-list.md` if it exists. Reviews are for the plan the team will actually use.
2. **Score the 20 criteria.** Work through the five categories in the order in `tool-rubric.md`, one category at a time. List the category's criteria on one short line each and ask what the vendor's own pages say, with the source and the date, and what the team found when it tested the tool. Give each criterion a score from 0 to 3 with the evidence, the source and the date. If the team skips a criterion, or the vendor's pages do not say, write "skipped" in the score column and do not score it. A skipped criterion counts for nothing, for or against the tool. List it under Not scored so the team can come back to it. The team can change any score and the reason goes in the evidence column.
3. **Set the weights.** Start from the default weights in `tool-rubric.md`. Ask whether the team wants to change them. They must add up to 100%.
4. **Add it up.** Average only the criteria that were scored in each category, multiply by the weight, and add the five results. A skipped criterion is left out of the average. If a whole category is skipped, share its weight across the other categories in proportion. Show the arithmetic so the team can check it, and say how many of the 20 criteria were scored.
5. **List what was not scored.** List each skipped criterion, and what the team may want to ask the vendor to confirm in writing. Nothing here counts against the tool.
6. **Decide.** The team writes what it decided in its own words, with its reasons. The scores inform the decision. The team makes it. Do not ask for a label such as go or no-go.
7. **Check against values.** Open `values.md` and ask how the decision lines up with it.
8. **Save it.** Copy `tool-evaluation-template.md` to `tool-evaluation.md` and match `tool-evaluation-example.md` exactly: the same headings and the same table columns every time, for every user. Then say: "Save tool-evaluation.md in your shared AI folder."

### Rules for the tool review

- Every score has a source and a date. A score without a source goes in flags.md.
- Use only the vendor's own pages and what the team tested. Do not score from memory.
- Prices and terms change, so say the date on every finding.
- Do not state what the law requires. Write "ask counsel" in `flags.md`.

## Hands off to

- `leadership-commitment` once the policy is settled. Bring `use-policy.md`.
- `ethics-grounding` at any stop point.
